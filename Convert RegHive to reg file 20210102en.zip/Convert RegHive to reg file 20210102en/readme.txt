Convert RegHive to reg file 20210102en - 20201227cn



this bat file using reg.exe and binmay.exe, is able to convert Sandboxie "RegHive" file to reg(text) file on Windows XP/7/10.
"reg.exe" is system file.
"binmay.exe" is from here: http://theoven.org/index.php?topic=2769.0



[Usage]
1.Copy "RegHive" file to same location(path) of "RegHive_to_reg.bat" batch file.
2.Run "RegHive_to_reg.bat" as Administrator.
3."RegHive_reg.txt" text file created(saved).





original post at china kafan forum(cn version):
https://bbs.kafan.cn/thread-2192026-1-1.html



